import pandas as pd
import numpy as np
import basictools as bt
import symfit as sf


class GlobalFitExp(object):
    def __init__(self, data, num_ts, list_tmax, list_tmin, const_lim=None, coeff_lim=None, x_first=None):
        self.data = data
        self.num_ts = num_ts
        self.list_tmax = list_tmax
        self.list_tmin = list_tmin
        self.const_lim = const_lim or 1.0
        self.coeff_lim = coeff_lim or 20.
        self.x_first = x_first or 80
        self.data_cols = self.data.columns
        self.num_fit = len(self.data_cols)
        self.x = dict()
        self.y = dict()
        self.time_scale = dict()
        self.coeff = dict()
        self.const = dict()
        self.fit_input = None
        self.glb_model = None
        self.glb_fit = None
        self.fit_result = None
        self.fit_data = None
        self.cmp_data = None
        self.fit_params = None
        self.initiate_variables()
        self.initiate_timescale()
        self.initiate_coeff()
        self.initiate_const()
        self.build_fit_model()

    def initiate_variables(self):
        for col in self.data.columns:
            str_col = str(col) if not isinstance(col, str) else col
            self.x[col], self.y[col] = sf.variables('x_' + str_col + ',' + 'y_' + str_col)

    def initiate_timescale(self):
        for n in range(self.num_ts):
            self.time_scale[n] = sf.parameters('t_' + str(n))[0]
            self.time_scale[n].max = self.list_tmax[n]
            self.time_scale[n].min = self.list_tmin[n]

    def initiate_const(self):
        for col in self.data.columns:
            str_col = str(col) if not isinstance(col, str) else col
            self.const[col] = sf.parameters('c_' + str_col)[0]
            self.const[col].max = np.abs(self.const_lim)
            self.const[col].min = - np.abs(self.const_lim)

    def initiate_coeff(self):
        for n in range(self.num_ts):
            self.coeff[n] = dict()
            for col in self.data.columns:
                str_col = str(col) if not isinstance(n, str) else col
                self.coeff[n][col] = sf.parameters('a_' + str(n) + '_' + str_col)[0]
                self.coeff[n][col].max = np.abs(self.coeff_lim)
                self.coeff[n][col].min = -np.abs(self.coeff_lim)

    def build_fit_model(self):
        glb_model = dict()
        for col in self.data_cols:
            glb_model_col = self.const[col]
            for n in range(self.num_ts):
                glb_model_col = glb_model_col + self.coeff[n][col] * sf.exp(
                    -(self.x[col] - self.x_first) / self.time_scale[n])
            glb_model[self.y[col]] = glb_model_col
        self.glb_model = sf.Model(glb_model)

    def run_fit_model(self):
        self.fit_input = dict()
        for col in self.data_cols:
            str_col = str(col) if not isinstance(col, str) else col
            self.fit_input['x_' + str_col] = np.array(self.data.index)
            self.fit_input['y_' + str_col] = np.array(self.data[col].values)
        self.glb_fit = sf.Fit(self.glb_model, **self.fit_input)
        self.fit_result = self.glb_fit.execute()

    def compute_fit_data(self):
        self.fit_data = dict()
        for col in self.data_cols:
            str_col = str(col) if not isinstance(col, str) else col
            kw = dict()
            kw['x_' + str_col] = np.array(self.data.index)
            kw['c_' + str_col] = self.fit_result.value(self.const[col])
            for n in range(self.num_ts):
                kw['t_' + str(n)] = self.fit_result.value(self.time_scale[n])
                kw['a_' + str(n) + '_' + str_col] = self.fit_result.value(self.coeff[n][col])
            self.fit_data[col] = pd.Series(self.glb_model[self.y[col]](**kw), index=self.data.index)
        self.fit_data = pd.DataFrame(self.fit_data)
        self.cmp_data = bt.dict2multi_df({'Data': self.data, 'Fit': self.fit_data})

    def get_fit_result(self):
        self.fit_params = dict()
        for col in self.data_cols:
            self.fit_params[col] = dict()
            self.fit_params[col]['c'] = self.fit_result.value(self.const[col])
            for n in range(self.num_ts):
                self.fit_params[col]['t' + str(n)] = self.fit_result.value(self.time_scale[n])
                self.fit_params[col]['a' + str(n)] = self.fit_result.value(self.coeff[n][col])
        self.fit_params = pd.DataFrame(self.fit_params)
