import pandas as pd
import numpy as np
import basictools as bt
from scipy.optimize import curve_fit


def func_1exp(x, c0, c1, t1):
    """
    fit function with 1-decay timescale
    """
    return c1 * np.exp(- x / t1) + c0


def func_2exp(x, c0, c1, c2, t1, t2):
    """
    fit function with 2-decay timescales
    """
    return c1 * np.exp(- x / t1) + c2 * np.exp(- x / t2) + c0


def func_3exp(x, c0, c1, c2, c3, t1, t2, t3):
    """
    fit function with 3-decay timescales
    """
    return c1 * np.exp(- x / t1) + c2 * np.exp(- x / t2)  + c3 * np.exp(- x / t3) + c0


fit_dict = {'1-timescale': func_1exp, '2-timescale': func_2exp, '3-timescale': func_3exp}
fit_index = {'1-timescale': ['c0', 'c1', 't1'],
             '2-timescale': ['c0', 'c1', 'c2', 't1', 't2'],
             '3-timescale': ['c0', 'c1', 'c2', 'c3', 't1', 't2', 't3']}


def fit_exp(data, fit_type='1-timescale'):
    """
    Fit spectral data with exponential decay
    :param data:
    :param fit_type:
    :return:
    """
    data = data.dropna()
    x = np.array(data.index)
    y = data.Spectrum.values
    popt, pcov = curve_fit(fit_dict[fit_type], x, y)
    fitted_data = pd.DataFrame({'Fitted_curve': pd.Series(fit_dict[fit_type](x, *popt), index=x)})
    fitted_params = pd.DataFrame({'Parameter': pd.Series(popt, index=fit_index[fit_type]),
                                  'Error': np.sqrt(pd.Series(np.diag(pcov), index=fit_index[fit_type]))})
    return fitted_data, fitted_params[['Parameter', 'Error']]


def func_quad_exp(x, a1, a2, a3, a4, c, t1, t2, t3, t4, x0):
    """
    fit function with 3-decay timescales
    """
    return a1 * np.exp(-(x-x0) / t1) + a2 * np.exp(-(x-x0) / t2) + a3 * np.exp(- (x-x0) / t3)\
           + a4 * np.exp(- (x-x0) / t4) + c

def func_qui_exp(x, a1, a2, a3, a4, a5, c, t1, t2, t3, t4, t5, x0):
    """
    fit function with 3-decay timescales
    """
    return a1 * np.exp(-(x-x0) / t1) + a2 * np.exp(-(x-x0) / t2) + a3 * np.exp(- (x-x0) / t3)\
           + a4 * np.exp(- (x-x0) / t4) + a5 * np.exp(- (x-x0) / t5) + c


def func_triple_exp(x, a1, a2, a3, c, t1, t2, t3, x0):
    """
    fit function with 3-decay timescales
    """
    return a1 * np.exp(-(x-x0) / t1) + a2 * np.exp(-(x-x0) / t2) + a3 * np.exp(- (x-x0) / t3) + c


def func_double_exp(x, a1, a2, c, t1, t2, x0):
    """
    fit function with 2-decay timescales
    """
    return a1 * np.exp(-(x-x0) / t1) + a2 * np.exp(-(x-x0) / t2) + c


def func_single_exp(x, a1, c, t1, x0):
    """
    fit function with 1-decay timescales
    """
    return a1 * np.exp(-(x-x0) / t1) + c


def fit_coeff_of_3exp(data, x_first, x_end, list_lambda, t1, t2, t3, x0):
    """
    Fit coeff of exp with fixed timescale
    :return:
    """
    tmp_data = data.loc[x_first:x_end].dropna()
    fit_params = dict()
    fit_errors = dict()
    fit_data = dict()
    for lbd in list_lambda:
        x = np.array(tmp_data.index)
        y = tmp_data[lbd]
        func = lambda x, a1, a2, a3, c: func_triple_exp(x, a1, a2, a3, c, t1, t2, t3, x0)
        popt, pcov = curve_fit(func, x, y, bounds=(-1., 1.))
        fit_params[lbd] = popt
        fit_errors[lbd] = np.diag(pcov)
        fit_data[lbd] = pd.Series(func(x, *popt), index=x)
    fit_params = pd.DataFrame(fit_params)
    fit_params.index = ['a1', 'a2', 'a3', 'c']
    fit_errors = pd.DataFrame(fit_errors)
    fit_errors.index = ['a1', 'a2', 'a3', 'c']
    fit_data = pd.DataFrame(fit_data)#.reindex_like(tmp_data)
    cmp_data = bt.dict2multi_df({lbd: pd.DataFrame({'Data': data[lbd], 'Fit': fit_data[lbd]}) for lbd in list_lambda})
    return cmp_data, fit_params, fit_errors


def fit_coeff_of_2exp(data, x_first, x_end, list_lambda, t1, t2, x0):
    """
    Fit coeff of exp with fixed timescale
    :return:
    """
    tmp_data = data.loc[x_first:x_end].dropna()
    fit_params = dict()
    fit_errors = dict()
    fit_data = dict()
    for lbd in list_lambda:
        x = np.array(tmp_data.index)
        y = tmp_data[lbd]
        func = lambda x, a1, a2, c: func_double_exp(x, a1, a2, c, t1, t2, x0)
        popt, pcov = curve_fit(func, x, y, bounds=(-1., 1.))
        fit_params[lbd] = popt
        fit_errors[lbd] = np.diag(pcov)
        fit_data[lbd] = pd.Series(func(x, *popt), index=x)
    fit_params = pd.DataFrame(fit_params)
    fit_params.index = ['a1', 'a2', 'c']
    fit_errors = pd.DataFrame(fit_errors)
    fit_errors.index = ['a1', 'a2', 'c']
    fit_data = pd.DataFrame(fit_data)#.reindex_like(tmp_data)
    cmp_data = bt.dict2multi_df({lbd: pd.DataFrame({'Data': data[lbd], 'Fit': fit_data[lbd]}) for lbd in list_lambda})
    return cmp_data, fit_params, fit_errors


def fit_coeff_of_1exp(data, x_first, x_end, list_lambda, t1, x0):
    """
    Fit coeff of exp with fixed timescale
    :return:
    """
    tmp_data = data.loc[x_first:x_end].dropna()
    fit_params = dict()
    fit_errors = dict()
    fit_data = dict()
    for lbd in list_lambda:
        x = np.array(tmp_data.index)
        y = tmp_data[lbd]
        func = lambda x, a1, c: func_single_exp(x, a1, c, t1, x0)
        popt, pcov = curve_fit(func, x, y, bounds=(-1., 1.))
        fit_params[lbd] = popt
        fit_errors[lbd] = np.diag(pcov)
        fit_data[lbd] = pd.Series(func(x, *popt), index=x)
    fit_params = pd.DataFrame(fit_params)
    fit_params.index = ['a1', 'c']
    fit_errors = pd.DataFrame(fit_errors)
    fit_errors.index = ['a1', 'c']
    fit_data = pd.DataFrame(fit_data)#.reindex_like(tmp_data)
    cmp_data = bt.dict2multi_df({lbd: pd.DataFrame({'Data': data[lbd], 'Fit': fit_data[lbd]}) for lbd in list_lambda})
    return cmp_data, fit_params, fit_errors


def fit_coeff_of_exp(data, x_first, x_end, list_lambda, list_ts, x0, bnd=100):
    """
    Fit coeff of exp with fixed timescale
    :return:
    """
    num_of_ts = len(list_ts)
    if num_of_ts==3:
        func_exp = lambda x, a1, a2, a3, c: func_triple_exp(x, a1, a2, a3, c,
                                                                list_ts[0], list_ts[1], list_ts[2], x0)
        param_list = ['a1', 'a2', 'a3', 'c']
    elif num_of_ts==2:
        func_exp = lambda x, a1, a2, c: func_double_exp(x, a1, a2, c, list_ts[0], list_ts[1], x0)
        param_list = ['a1', 'a2', 'c']
    elif num_of_ts==1:
        func_exp = lambda x, a1, c: func_single_exp(x, a1, c, list_ts[0], x0)
        param_list = ['a1', 'c']
    elif num_of_ts==4:
        func_exp = lambda x, a1, a2, a3, a4, c: func_quad_exp(x, a1, a2, a3, a4, c,
                                                                list_ts[0], list_ts[1], list_ts[2], list_ts[3], x0)
        param_list = ['a1', 'a2', 'a3', 'a4', 'c']
    elif num_of_ts==5:
        func_exp = lambda x, a1, a2, a3, a4, a5, c: func_qui_exp(x, a1, a2, a3, a4, a5, c,
                                                                list_ts[0], list_ts[1], list_ts[2], list_ts[3], list_ts[4], x0)
        param_list = ['a1', 'a2', 'a3', 'a4', 'a5', 'c']
    else:
        raise ValueError('Number of timescale greater than 5, please use a smaller number')

    tmp_data = bt.drop_na_column(data.loc[x_first:x_end]).dropna()
    fit_params = dict()
    fit_errors = dict()
    fit_data = dict()
    for lbd in list_lambda:
        x = np.array(tmp_data.index)
        y = tmp_data[lbd]
        popt, pcov = curve_fit(func_exp, x, y, bounds=(-bnd, bnd))
        fit_params[lbd] = popt
        fit_errors[lbd] = np.diag(pcov)
        fit_data[lbd] = pd.Series(func_exp(x, *popt), index=x)
    fit_params = pd.DataFrame(fit_params)
    fit_params.index = param_list
    fit_errors = pd.DataFrame(fit_errors)
    fit_errors.index = param_list
    fit_data = pd.DataFrame(fit_data)
    cmp_data = bt.dict2multi_df({lbd: pd.DataFrame({'Data': data[lbd], 'Fit': fit_data[lbd]}) for lbd in list_lambda})
    return cmp_data, fit_params, fit_errors


def fit_single_curve_exp_func(data, x0, xe, t_init, coeff_init):
    n_ts = len(t_init)
    test_data = data.loc[x0:xe]
    xdata = np.array(test_data.index)
    ydata = np.array(test_data.values)
    params_init = [coeff_init] * n_ts + t_init + [coeff_init]

    def func4(x, a1, a2, a3, a4, t1, t2, t3, t4, c):
        return a1 * np.exp(-(x - x0) / t1) + a2 * np.exp(- (x - x0) / t2) + a3 * np.exp(- (x - x0) / t3) + a4 * np.exp(
            - (x - x0) / t4) + c

    def func3(x, a1, a2, a3, t1, t2, t3, c):
        return a1 * np.exp(-(x - x0) / t1) + a2 * np.exp(- (x - x0) / t2) + a3 * np.exp(- (x - x0) / t3) + c

    def func2(x, a1, a2, t1, t2, c):
        return a1 * np.exp(-(x - x0) / t1) + a2 * np.exp(- (x - x0) / t2) + c

    def func1(x, a1, t1, c):
        return a1 * np.exp(-(x - x0) / t1) + c

    if n_ts == 3:
        func = func3
        param_names = ['a1', 'a2', 'a3', 't1', 't2', 't3', 'c']
    elif n_ts == 2:
        func = func2
        param_names = ['a1', 'a2', 't1', 't2', 'c']
    elif n_ts == 1:
        func = func1
        param_names = ['a1', 't1', 'c']
    else:
        print ('Fit only less than three timescale')

    popt, pcov = curve_fit(func, xdata, ydata, params_init)
    fit_params = {'Params': pd.Series(popt, index=param_names),
                  'Errors': pd.Series(np.sqrt(np.diag(pcov)), index=param_names)}
    fit_params = pd.DataFrame(fit_params)
    fit_data = pd.Series(func(xdata, *popt), index=xdata)
    cmp_data = pd.DataFrame({'Data': data, 'Fit': fit_data, 'Res': test_data - fit_data})
    return popt, fit_params, fit_data, cmp_data


class SingleCurveFit(object):
    def __init__(self, data, t_init, coeff_init, x_begin, x_end):
        self._data = data
        self._t_init = t_init
        self._coeff_init = coeff_init
        self._x_begin = x_begin
        self._x_end = x_end
        self._popt = None
        self._params_fit = None
        self._all_data = None
        self._fit_data = None
        self._chi2 = None

    def run_fit(self):
        result = fit_single_curve_exp_func(self._data, self._x_begin, self._x_end, self._t_init, self._coeff_init)
        self._popt, self._params_fit, self._fit_data, self._all_data = result
        self._chi2 = ((self._all_data["Fit"] - self._all_data["Data"]) ** 2 / self._all_data["Fit"].abs()).sum()
        self._chi2b = ((self._all_data["Fit"] - self._all_data["Data"]) ** 2).sum()
        #chi2 = pd.DataFrame([[self._chi2, np.nan]], index=['chi2'], columns=['Params', 'Errors'])
        chi2b = pd.DataFrame([[self._chi2b, np.nan]], index=['chi2'], columns=['Params', 'Errors'])
        self._params_fit = pd.concat([self._params_fit, chi2b], axis=0)
        self._params_fit = self._params_fit[['Params', 'Errors']]

    def save_data(self, path, save_dir, save_file):
        bt.save_data(self._all_data, path, save_dir, save_file)

    def save_params(self, path, save_dir, save_file):
        bt.save_data(self._params_fit, path, save_dir, save_file)


class FitAllCoeff(object):
    def __init__(self, data, list_lambda, list_ts, x_begin, x_end, bnd=100):
        self._data = data
        self._list_lambda = list_lambda
        self._list_ts = list_ts
        self._x_begin = x_begin
        self._x_end = x_end
        self._all_data = None
        self._params_fit = None
        self._coeffs_fit = None
        self._coeffs_error = None
        self._bound = bnd

    def run_fit(self):
        self._all_data, self._coeffs_fit, self._coeffs_error = \
            fit_coeff_of_exp(self._data, self._x_begin, self._x_end,
                             self._list_lambda, self._list_ts,
                             self._x_begin, self._bound)
        self._params_fit = bt.dict2multi_df({'Params': self._coeffs_fit, 'Errors': self._coeffs_error})
        self._params_fit = self._params_fit.swaplevel(0, 1, axis=1)
        self._params_fit = bt.dict2multi_df({k: self._params_fit[k][['Params', 'Errors']]
                                             for k in set(self._params_fit.columns.get_level_values(0))})
        self._chi2 = {lbd: ((self._all_data[lbd]["Fit"] - self._all_data[lbd]["Data"]) ** 2).sum()
                      for lbd in set(self._all_data.columns.get_level_values(0))}
        self._chi2 = pd.Series(self._chi2)
        # self._chi2 = {lbd: ((self._all_data[lbd]["Fit"] - self._all_data[lbd]["Data"]) ** 2
        #                     / self._all_data[lbd]["Fit"].abs()).sum()
        #               for lbd in set(self._all_data.columns.get_level_values(0))}
        # self._chi2 = pd.Series(self._chi2)

    def save_data(self, path, save_dir, save_file):
        cols = [(l, d) for l in np.sort(self._all_data.columns.get_level_values(0).unique())
                for d in ['Data', 'Fit']]
        bt.save_data(self._all_data[cols], path, save_dir, save_file)

    def save_coeffs_fit(self, path, save_dir, save_file):
        bt.save_data(self._coeffs_fit.T, path, save_dir, save_file)

    def save_coeffs_error(self, path, save_dir, save_file):
        bt.save_data(self._coeffs_error.T, path, save_dir, save_file)

    def save_params(self, path, save_dir, save_file):
        bt.save_data(self._params_fit.T, path, save_dir, save_file)
