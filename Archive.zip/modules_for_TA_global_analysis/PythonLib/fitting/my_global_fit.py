import numpy as np
import pandas as pd
import basictools as bt
from scipy.optimize import leastsq


class MyGlobalFit(object):
    """
    My global fit using leastsq function of scipy package
    """
    def __init__(self, data, t_init, coeff_init, x_begin, x_end, use_norm=True):
        """
        Constructor
        :param data:
        :param t_init:
        :param coeff_init:
        """
        self._data = data.loc[x_begin:x_end]
        self._t_init = t_init
        self._coeff_init = coeff_init
        self._x_begin = x_begin
        self._x_end = x_end
        self._use_norm = use_norm
        self._norm_data = self._data.copy()
        self._norm_factor = np.sign(self._data.abs().mean())
        if self._use_norm:
            self._norm_factor = self._data.abs().max()
            self._norm_data = self._data.div(self._norm_factor, axis=1)
        self._cols = self._data.columns
        self._n_col = len(self._cols)
        self._result = None
        self._coeff = None
        self._error_coeff = None
        self._time_scale = None
        self._chi2 = None
        self._pcov = None
        self._all_data = None
        self.report_coeff = None
        self.report_ts = None
        self._define_paramters()

    def _define_paramters(self):
        """
        Build initial paramters
        :return:
        """
        self._n_ts = len(self._t_init)
        a0 = [self._coeff_init] * self._n_ts
        c0 = [self._coeff_init]
        param_t = self._t_init
        param_a = a0 * self._n_col
        param_c = c0 * self._n_col
        self._params_init = param_a + param_t + param_c
        self._a_names = ['a' + str(k) for k in range(1, self._n_ts + 1)]
        self._t_names = ['t' + str(k) for k in range(1, self._n_ts + 1)]
        self._c_names = ['c']

    def _get_fit_data(self):
        xdata = np.array(self._norm_data.index)
        a_dict, t_dict, c_dict = get_params(self._result[0], self._n_ts, self._cols)
        yfit = dict()
        for col in self._cols:
            yfit[col] = func(xdata, a_dict[col], t_dict, c_dict[col], self._x_begin)
        yfit = pd.DataFrame(yfit, index=xdata)
        cmp_data = bt.dict2multi_df({'Data': self._norm_data, 'Fit': yfit, 'Res': self._norm_data - yfit})
        return cmp_data

    def run_global_fit(self):
        """
        Run global fit
        """
        # Run optimization of parameters
        args = (self._norm_data, self._n_ts, self._x_begin)
        self._result = leastsq(leastsq_function, self._params_init, args=args, full_output=1)

        # Get fit results
        self._coeff, self._error_coeff, self._time_scale, self._pcov, self._chi2 = get_param_result(
            self._result, self._norm_data, self._n_ts, self._x_begin, self._a_names, self._t_names)
        self._coeff = self._coeff.mul(self._norm_factor, axis=1).T
        self._error_coeff = self._error_coeff.mul(self._norm_factor, axis=1).T
        self._all_data = self._get_fit_data().mul(self._norm_factor, axis=1, level=1)
        self.report_coeff = bt.dict2multi_df({'Params': self._coeff.T,
                                              'Errors': self._error_coeff.T}).swaplevel(0, 1, axis=1)
        self.report_coeff = bt.dict2multi_df({lbd: self.report_coeff[lbd][['Params', 'Errors']]
                                        for lbd in set(self.report_coeff.columns.get_level_values(0))})
        self._chi2 = (self._all_data['Res'] ** 2).sum().sum()
        self.report_ts = pd.DataFrame([[np.nan, self._chi2]], columns=['Errors', 'Params'], index=['chi2'])
        self.report_ts = pd.concat([self._time_scale, self.report_ts], axis=0)[['Params', 'Errors']]

    def save_data(self, path, save_dir, save_file='global_fit_data.dat'):
        bt.save_data(self._all_data, path, save_dir, save_file)

    def save_coeff(self, path, save_dir, save_file='global_fit_coeff.dat'):
        bt.save_data(self.report_coeff, path, save_dir, save_file)

    def save_timescale(self, path, save_dir, save_file='global_fit_timescale.dat'):
        bt.save_data(self.report_ts, path, save_dir, save_file)


def func(x, a_dict, t_dict, c, x0):
    """
    x: array of data
    a_dict: dict of coeff with key is 1, 2, 3, ...
    t_dict: dict of coeff with key is 1, 2, 3, ...
    """
    res = c
    for k in a_dict.keys():
        res += a_dict[k] * np.exp(-(x - x0) / t_dict[k])
    return res


def leastsq_function(params, *args):
    data = args[0]
    n_ts = args[1]
    x0 = args[2]
    x = np.array(data.index)
    cols = data.columns
    a_dict, t_dict, c_dict = get_params(params, n_ts, cols)
    yfit = dict()
    for col in cols:
        yfit[col] = func(x, a_dict[col], t_dict, c_dict[col], x0)
    yfit = pd.DataFrame(yfit, index=x)
    dy = (data.T.stack() - yfit.T.stack()).values
    return dy


def get_params(params, n_ts, cols):
    n_col = len(cols)
    a_dict = dict()
    count = 0
    for col in cols:
        a_dict[col] = dict()
        for k in range(0, n_ts):
            a_dict[col][k] = params[n_ts * count + k]
        count += 1
    t_dict = dict()
    for k in range(0, n_ts):
        t_dict[k] = params[n_ts * n_col + k]

    c_dict = dict()
    count = 0
    for col in cols:
        c_dict[col] = params[n_ts * (n_col + 1) + count]
        count += 1
    return a_dict, t_dict, c_dict


def get_param_result(result, data, n_ts, x0, a_names, t_names):
    #Get parameter and correlation
    params = result[0]
    pcor = result[1]
    cols = data.columns
    n_data = len(data.index) * len(cols)
    n_params = len(params)
    #Compute variance
    chi2 = (leastsq_function(params, data, n_ts, x0) ** 2).sum()
    s_sq = chi2 / (n_data - n_params)
    pcov = pcor * s_sq
    #Build parameter
    a_dict, t_dict, c_dict = get_params(params, n_ts, cols)
    ea_dict, et_dict, ec_dict = get_params(np.sqrt(np.diag(pcov)), n_ts, cols)
    a_dict = pd.DataFrame(a_dict)
    a_dict.index = a_names
    ea_dict = pd.DataFrame(ea_dict)
    ea_dict.index = a_names
    time_scale = pd.DataFrame({'Params': pd.Series(t_dict), 'Errors': pd.Series(et_dict)})
    time_scale.index = t_names
    c_dict = pd.DataFrame({'c': pd.Series(c_dict)}).T
    ec_dict = pd.DataFrame({'c': pd.Series(ec_dict)}).T
    coeff = pd.concat([a_dict, c_dict])
    error_coeff = pd.concat([ea_dict, ec_dict])
    return coeff, error_coeff, time_scale, pcov, chi2
