import pandas as pd
import numpy as np
import basictools as bt
from scipy.optimize import curve_fit


def exp_func(x, x0, a_list, t_list, c):
    f = c
    for k in range(len(a_list)):
        f += a_list[k] * np.exp(-(x - x0) / t_list[k])
    return f


class FixedTimeFit(object):
    """
    Fixed time fit using leastsq function of scipy package
    """
    def __init__(self, data, t_fixed, t_init, coeff_init, x_begin, x_end):
        """
        Constructor
        :param data:
        :param t_init:
        :param coeff_init:
        """
        self._odata = data
        self._data = data.loc[x_begin:x_end]
        self._t_fixed = t_fixed
        self._t_init = t_init
        self._coeff_init = coeff_init
        self._x_begin = x_begin
        self._x_end = x_end
        self._popt = None
        self._pcov = None
        self._params_fit = None
        self._all_data = None
        self._define_paramters()

    def _define_paramters(self):
        """
        Build initial paramters
        :return:
        """
        self._n_tf = len(self._t_fixed)
        self._n_ts = len(self._t_init)
        param_a = [self._coeff_init] * (self._n_ts + self._n_tf)
        param_c = [self._coeff_init]
        param_t = self._t_init
        self._params_init = param_a + param_t + param_c
        self._a_names = ['a' + str(k) for k in range(1, self._n_ts + 1)]
        self._a_names += ['af' + str(k) for k in range(1, self._n_tf + 1)]
        self._t_names = ['t' + str(k) for k in range(1, self._n_ts + 1)]
        self._tf_names = ['tf' + str(k) for k in range(1, self._n_tf + 1)]
        self._c_names = ['c']

    def _get_fit_data(self):
        xdata = np.array(self._data.index)
        fit_data = pd.Series(self.fit_func(xdata, *self._popt), index=xdata)
        self._all_data = pd.DataFrame({'Data': self._odata, 'Fit': fit_data, 'Res': self._data - fit_data})
        params = pd.Series(self._popt, index=self._a_names + self._t_names + self._c_names)
        errors = pd.Series(np.sqrt(np.diag(self._pcov)), index=self._a_names + self._t_names + self._c_names)
        fit_params = pd.DataFrame({'Params': params, 'Errors': errors})
        fixed_params = pd.DataFrame({'Params': pd.Series(self._t_fixed, index=self._tf_names)})
        fixed_params['Errors'] = 0 * fixed_params['Params']
        self._params_fit = pd.concat([fit_params, fixed_params], axis=0)
        self._params_fit.index.names = ['Name']
        self._params_fit = self._clean_fit_params()
        #self._chi2 = ((self._all_data["Fit"] - self._all_data["Data"]) ** 2 / self._all_data["Fit"].abs()).sum()
        #chi2 = pd.DataFrame([[self._chi2, np.nan]], index=['chi2'], columns=['Params', 'Errors'])
        self._chi2b = ((self._all_data["Fit"] - self._all_data["Data"]) ** 2).sum()
        chi2b = pd.DataFrame([[self._chi2b, np.nan]], index=['chi2'], columns=['Params', 'Errors'])
        self._params_fit = pd.concat([self._params_fit, chi2b], axis=0)
        self._params_fit = self._params_fit[['Params', 'Errors']]

    def _clean_fit_params(self):
        time_clean = np.round(self._params_fit.loc[self._t_names + self._tf_names].sort_values('Params'), 2)
        time_clean['NewName'] = ['t' + str(k) for k in range(1, self._n_ts + self._n_tf + 1)]
        time_map = time_clean['NewName'].to_dict()
        time_clean = time_clean.set_index('NewName')#[['Params', 'Errors']]
        coeff_map = {k.replace('t', 'a'): v.replace('t', 'a') for k, v in time_map.items()}
        coeff_clean = self._params_fit.loc[self._a_names].rename(index=coeff_map).sort_index()
        c_clean = self._params_fit.loc[self._c_names]
        params_clean = pd.concat([coeff_clean, time_clean, c_clean])
        return params_clean

    def fit_func(self, x, *args):
        a_list = list(args[0:self._n_ts + self._n_tf])
        t_list = list(args[self._n_ts + self._n_tf:-1])
        c = args[-1]
        return exp_func(x, self._x_begin, a_list, t_list + self._t_fixed, c)

    def run_fit(self):
        """
        Run fit
        """
        # Run optimization of parameters
        xdata = np.array(self._data.index)
        ydata = np.array(self._data.values)
        func = lambda x, *args: self.fit_func(x, *args)
        self._popt, self._pcov = curve_fit(func, xdata, ydata, self._params_init)
        self._get_fit_data()

    def save_data(self, path, save_dir, save_file):
        bt.save_data(self._all_data, path, save_dir, save_file)

    def save_params(self, path, save_dir, save_file):
        bt.save_data(self._params_fit, path, save_dir, save_file)
