import numpy as np
import pandas as pd


def load_transient_spectrum_data(folder_name, file_name):
    """
    Load spectral signals
    :param folder_name:
    :param file_name:
    :return:
    """
    data = pd.read_table(folder_name + file_name, header=None, sep='\t').T
    data = data.set_index(0)
    data.index.names = ['Wave Length']
    data.columns = ['S11', 'S21', 'S12', 'S22']
    data.columns.names = ['Signal']
    return data


def load_absorption_spectrum_data(folder_name1, folder_name2, file_name):
    """
    Load spectral signals
    :param folder_name:
    :param file_name:
    :return:
    """
    data1 = pd.read_table(folder_name1 + file_name, header=None, sep='\t').T
    data1 = data1.set_index(0)
    data2 = pd.read_table(folder_name2 + file_name, header=None, sep='\t').T
    data2 = data2.set_index(0)
    data = data1.copy()
    data[1] = data1[2]
    data[2] = data1[4]
    data[3] = data2[2]
    data[4] = data2[4]
    data.index.names = ['Wave Length']
    data.columns = ['S11', 'S21', 'S12', 'S22']
    data.columns.names = ['Signal']
    return data


def compute_log_spectrum(data_spectral, wave_length, delta_lambda):
    """
    Compute log signal then smooth data
    :param data:
    :param wave_length:
    :param delta_lambda:
    :return:
    """
    data = data_spectral.replace(0, np.nan)
    y = np.log10(data['S22'] / data['S21']) - np.log10(data['S12'] / data['S11'])
    y_filter = y[y.index > wave_length - delta_lambda]
    y_filter = y_filter[y_filter.index < wave_length + delta_lambda]
    y_avg = y_filter.mean()
    return y, y_avg
