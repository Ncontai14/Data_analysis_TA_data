import pandas as pd
import numpy as np


def average_over_filter(data, wave_length, window):
    """
    Filter data with a threshold and average within a window
    :param data:
    :param wave_length:
    :param window:
    :return: time series of a decay for the given wave length
    """
    data_filter = data[data.index > wave_length - window]
    data_filter = data_filter[data_filter.index < wave_length + window]
    return data_filter.mean()


def all_average_over_filter(data, first_wavelength, increment, window):
    """
    faire la moyenne tous les increment nm
    :param data:
    :param first_wavelength:
    :param increment:
    :param window:
    :return:
    """
    last_wavelength = data.index[-1]
    list_wavelength = np.arange(first_wavelength, last_wavelength, increment)
    wanted_data = dict()
    for wl in list_wavelength:
        wanted_data[int(wl)] = average_over_filter(data, wl, window)
    wanted_data = pd.DataFrame(wanted_data)
    return wanted_data


def smooth_data(data, delta_lambda, lower_lambda, upper_lambda):
    """
    Smoothing and filtering data
    :param data:
    :param wave_length:
    :param delta_lambda:
    :return:
    """
    w = pd.Series(data.index)
    scale = (w.values[-1] - w.values[0]) / len(w)
    span = int(delta_lambda / scale)
    data_smooth = data.rolling(span, min_periods=0).mean().shift(span / 2)
    data_smooth = data_smooth[data_smooth.index > lower_lambda]
    data_smooth = data_smooth[data_smooth.index < upper_lambda]
    return data_smooth


