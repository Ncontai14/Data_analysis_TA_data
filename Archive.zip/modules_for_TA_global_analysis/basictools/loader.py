import os
import pandas as pd
import numpy as np
from scipy.interpolate import interp1d


def read_data_with_inf(folder_name, file_name):
    """
    Load data file and correct the problem with Inf and -Inf
    :param folder_name:
    :param file_name:
    :return: data frame of float
    """
    data = pd.read_table(folder_name + file_name, header=None, sep='\t')
    for col in data.columns:
        new_col = []
        for d in data[col]:
            if d == '  -Inf':
                new_col += [-np.Inf]
            elif d == '  Inf':
                new_col += [np.Inf]
            else:
                new_col += [float(d)]
        data[col] = new_col
    return data


def read_data_with_inf2(path):
    """
    Load data file and correct the problem with Inf and -Inf
    :param path:
    :return: data frame of float
    """
    data = pd.read_table(path, header=None, sep='\t')
    for col in data.columns:
        new_col = []
        for d in data[col]:
            if d == '  -Inf':
                new_col += [-np.Inf]
            elif d == '  Inf':
                new_col += [np.Inf]
            else:
                new_col += [float(d)]
        data[col] = new_col
    return data


def interp_tail_data(spec_data, lambda_tail=499, increment=20):
    new_spec = dict()
    for lbd in spec_data.columns:
        xin = np.array(spec_data.iloc[lambda_tail:].index)
        yin = spec_data.iloc[lambda_tail:][lbd].values
        f = interp1d(xin, yin)
        xnew = np.arange(xin.min(), xin.max(), increment)
        ynew = f(xnew)
        xfin = np.array(spec_data.iloc[:lambda_tail].index)
        yfin = spec_data.iloc[:lambda_tail][lbd].values
        xfin = list(xfin) + list(xnew)
        yfin = list(yfin) + list(ynew)
        new_spec[lbd] = pd.Series(yfin, index=xfin)
    new_spec = pd.DataFrame(new_spec)
    return new_spec


def interp_head_data(spec_data, lambda_head=499, increment=20):
    new_spec = dict()
    for lbd in spec_data.columns:
        xin = np.array(spec_data.iloc[:lambda_head].index)
        yin = spec_data.iloc[:lambda_head][lbd].values
        f = interp1d(xin, yin)
        xnew = np.arange(xin.min(), xin.max(), increment)
        ynew = f(xnew)
        xfin = np.array(spec_data.iloc[lambda_head:].index)
        yfin = spec_data.iloc[lambda_head:][lbd].values
        xfin = list(xnew) + list(xfin)
        yfin = list(ynew) + list(yfin)
        new_spec[lbd] = pd.Series(yfin, index=xfin)
    new_spec = pd.DataFrame(new_spec)
    return new_spec


def save_data(df, path, save_dir, save_file):
    if not os.path.isdir(path + save_dir):
        os.makedirs(path + save_dir)
    df.to_csv(path + save_dir + save_file)
