import pandas as pd
import numpy as np
from functools import reduce


def nnan_shift(self, *args, **kwargs):
    """
    shift method without nan values
    Parameters
    ----------
    self: input dataframe or time series
    kwargs: standard pandas shift arguments

    Returns
    -------
    shifted data, ignoring nan values
    """
    # if isinstance(self, pd.DataFrame):
    #     shifted = {col: nnan_shift(self[col], *args, **kwargs) for col in self.columns}
    #     return pd.DataFrame(shifted)
    #
    # tmp = self.dropna()
    # if len(tmp) == 0:
    #     return self
    # return tmp.shift(*args, **kwargs).reindex(self.index)
    return self.shift(1)

def nnan_diff(self):
    """
    diff method without nan values
    Parameters
    ----------
    self: input dataframe or time series

    Returns
    -------
    diffed data, ignoring nan values
    """
    if isinstance(self, pd.DataFrame):
        diffed = {col: nnan_diff(self[col]) for col in self.columns}
        return pd.DataFrame(diffed)
    tmp = self.dropna()
    if len(tmp) == 0:
        return self
    s = nnan_shift(tmp, periods=1.)
    return (tmp - s).reindex(self.index)


def cap(self, level):
    """
    cap values between [-level, level] and normalize to [-1, 1]
    Parameters
    ----------
    self: input dataframe or series
    level: cap level

    Returns
    -------
    capped: normalized between [-1, 1]
    """
    return self.clip(-level, level) / level


def get_active_columns_count(self):
    """
    count active columns over time
    Parameters
    ----------
    self: input dataframe

    Returns
    -------
    Series: number of active columns over time
    """
    return (1. - pd.isnull(self.fillna(method='pad'))).sum(axis=1)


def sum_active_columns(self):
    """
    sum columns values by fixing the same number of active columns
    Parameters
    ----------
    self: input dataframe

    Returns
    -------
    Series

    """
    nap = get_active_columns_count(self)
    m = nap.max()
    tmp = self.fillna(0).sum(axis=1) * m / nap
    tmp[nap == 0] = np.nan
    return tmp


def mean_active_columns(self):
    """
    mean columns values by fixing the same number of active columns
    Parameters
    ----------
    self: input dataframe

    Returns
    -------
    Series

    """
    nap = get_active_columns_count(self)
    tmp = self.fillna(0).sum(axis=1) / nap
    tmp[nap == 0] = np.nan
    return tmp

def drop_na_row(df):
    """
    Drop nan row for dataframe
    Parameters
    ----------
    df: input dataframe

    Returns
    -------
    dataframe
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError('Input is not a dataframe: ' + str(type(df)))
    ncols = len(df.columns)
    isnan = df.isnull()
    nb_nan = isnan.sum(axis=1)
    return df.loc[nb_nan < ncols]


def drop_na_column(df):
    """
    Drop nan column for dataframe

    Parameters
    ----------
    df: input dataframe
    axis: 0 for rows, 1 for columns
    Returns
    -------
    dataframe
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError('Input is not a dataframe: ' + str(type(df)))

    nrows = len(df.index)
    isnan = pd.isnull(df)
    nb_nan = isnan.sum()
    non_nan_colums = [col for col in df.columns if nb_nan[col] < nrows]
    return df[non_nan_colums]


def array2multi_df(dataframes_list, groupnames_list, align='union'):
    """
    Arrays to dataframe conversion method

    Parameters
    ----------
    dataframes_list
    groupnames_list
    align: align method 'union'/'intersection', default value: 'union'

    Returns
    -------
    multi index dataframe
    """
    if align:
        if align == 'union':
            indexes = [d.index for d in dataframes_list]
            union_index = reduce(lambda x, y: x.union(y), indexes)
        elif align == 'intersection':
            indexes = [d.index for d in dataframes_list]
            union_index = reduce(lambda x, y: x.intersection(y), indexes)
        else:
            raise ValueError('Unsupported align argument')

        dataframes_list = [d.reindex(union_index) for d in dataframes_list]

    result = pd.concat(dataframes_list, keys=groupnames_list, axis=1)
    return result


def dict2multi_df(df_dict):
    """
    Convert a dictionary of dataframe to a multi-index dataframe
    Parameters
    ----------
    df_dict

    Returns
    -------

    """
    return array2multi_df(df_dict.values(), df_dict.keys())


def add_level_to_multi_df(df, level_name, level_value, first_place=True):
    """
    Add new level to multiindex (column) dataframe
    Parameters
    ----------
    df: Input dataframe
    level_name
    level_value
    first_place: boolean, True when we want to add new level to the top order
    Returns
    -------
    multiindex dataframe
    """
    current_levels = df.columns.names

    def _level_name(level_order, name=None):
        if not name:
            name = 'level_' + str(level_order)
        return name

    current_levels = [_level_name(i, current_levels[i]) for i in range(len(current_levels))]
    df.columns.names = current_levels
    df[level_name] = level_value
    df.set_index(level_name, append=True, inplace=True)
    df = df.unstack()
    if first_place:
        df = df.reorder_levels([level_name] + current_levels, axis=1)
    return df


def list2str(input_list, sep=', '):
    """
    Convert a list to string with separator
    Parameters
    ----------
    input_list: input list
    sep: separator, default = ', '

    Returns
    -------
    a string
    """
    if not isinstance(input_list, list):
        raise TypeError('Input should be a list')
    return sep.join(str(e) for e in input_list)


def dict2str(input_dict, sep=', '):
    """
    Convert a dictionary to string with separator
    Parameters
    ----------
    input_dict: input dictionary
    sep: separator, default = ', '

    Returns
    -------
    a string
    """
    if not isinstance(input_dict, dict):
        raise TypeError('Input should be a dictionary')
    return sep.join(str(k) + ': ' + str(v) for k, v in input_dict.iteritems())


def series2str(input_series, sep=', '):
    """
    Convert a time series to string with separator
    Parameters
    ----------
    input_series: input time series
    sep: separator, default = ', '

    Returns
    -------
    a string
    """
    if not isinstance(input_series, pd.Series):
        raise TypeError('Input should be a Series')
    return dict2str(dict(input_series))


def df2str(df, sep=', ', axis=0):
    """
    convert a data frame to a list of string
    Parameters
    ----------
    df: input dataframe
    sep: separator, default = ', '
    axis: default value 0. Each index is an element of list
    Returns
    -------
    a list of string
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError('Input should be a DataFrame')
    if axis == 1:
        return df2str(df.T, sep, axis=0)
    return ['[' + series2str(df.loc[i], sep) + '] ' + str(i) for i in df.index]


def to_str(input_object, sep=', ', **kw):
    """
    Convert an object to string with separator
    Parameters
    ----------
    input_object: input object
    sep: separator, default = ', '

    Returns
    -------
    a string
    """
    if isinstance(input_object, list):
        return list2str(input_object, sep)
    elif isinstance(input_object, dict):
        return dict2str(input_object, sep)
    elif isinstance(input_object, pd.Series):
        return series2str(input_object, sep)
    elif isinstance(input_object, pd.DataFrame):
        return df2str(input_object, sep, **kw)
    elif isinstance(input_object, pd.Index):
        return list2str(list(input_object))
    else:
        try:
            return str(input_object)
        except:
            raise Warning('%s is unsupported, input should be a list/dict/Series/DataFrame/Index'
                          % type(input_object))


